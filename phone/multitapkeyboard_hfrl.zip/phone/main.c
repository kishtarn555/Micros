/*
 * phone.c
 *
 * Created: 16/02/2023 01:54:56 p. m.
 * Author : Ferna
 */ 

#define F_CPU 8000000
#include <avr/io.h>
#include <util/delay.h>
#include <stdint.h>
#include <avr/interrupt.h>

#include "lcd.h"

volatile uint8_t press;

int main(void)
{
    /* Replace with your application code */
	DDRA = 2;
	PORTA = 1;
	TIMSK = (1<<OCIE0);
	OCR0 = 249;
	
	
	
	
	//CTC using 256scale
	TCCR0 = (1 << WGM01)|(1 << CS02);
	//LCD	
	lcd_init(LCD_DISP_ON);
	
	press = 0;
	int8_t pos =-1;
	uint8_t c = 0;
	
	sei();
    while (1)  {
		if ((PINA & 1))
			continue;
	
		_delay_ms(50);
		while(!(PINA & 1));
		_delay_ms(50);
		if (press ==0) {			
			c=0;
			if (pos < 15) {
				pos++;
			} else {
				pos=-1;
				lcd_gotoxy(0,0);
				lcd_puts("                ");				
				continue;
			}
		} else {	
			c++;
			c%=26;				
		}
		
		lcd_gotoxy(pos,0);			
		lcd_putc('A'+c);			
		press=125;		
	}
}

ISR(TIMER0_COMP_vect) {
	// Note: for UX purposes, we only measure the time between presses, not between edges.
	if (press >0 && (PINA & 1)) {
		press--;
	}
	// else {
		//press=125;
		//PORTA^=2;		
	//}
}

