/*
 * eepromTest.c
 *
 * Created: 09/03/2023 04:03:24 p. m.
 * Author : Ferna
 */ 

#include "globals.h"
#include "lcd.h"
#include "keyboard.h"
#include "myeeprom.h"
#include <util/delay.h>
#include <avr/io.h>
#include <stdint.h>

uint16_t val;

void display() {
	lcd_gotoxy(0,0);
	lcd_putc(val%10+'0');
	lcd_putc(val/10%10+'0');
	lcd_putc(val/100%10+'0');
	lcd_putc(val/1000%10+'0');
}

int main(void)
{	
	lcd_init(LCD_DISP_ON);
	keyboardInit();
	DDRA = 255;
	
	val = eeRead16(1);
    while (1) 
    {
		display();		
		_delay_ms(10);
		uint8_t nexo = keyboardDecode(keyboardReadOnRelease())-'0';
		_delay_ms(10);
		PORTA = nexo;	
		if (nexo > 9) continue;
		val = val%1000;
		val*=10;
		val+=nexo;
		eeWrite16(1, val);
    }
}

