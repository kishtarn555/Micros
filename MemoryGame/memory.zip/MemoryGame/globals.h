/*
 * globals.h
 *
 * Created: 22/02/2023 02:37:14 a. m.
 *  Author: Ferna
 */ 


#ifndef GLOBALS_H_
#define GLOBALS_H_

#define F_CPU 1000000



#endif /* GLOBALS_H_ */