/*
 * Interrputs_Die.c
 *
 * Created: 14/02/2023 12:00:57 p. m.
 * Author : Hector Fernando Ricardez Lara
 */ 
#define F_CPU 8000000
//#define UP_DEBUG

#include <util/delay.h>
#include <avr/io.h>
#include <avr/interrupt.h>
#include <stdint.h>
#include <stdlib.h>
volatile uint16_t seed;
volatile uint8_t number;

int main(void) {
	DDRD = 0;
	PORTD = 0;
	DDRA = 255;	
	DDRB = 255;
	PORTA = PORTB = 0;
	sei();
	//Avoid tripping the interrupt on start
	GIFR |= (1<<6);
	// Active interrupt 1
	GICR |= (1<< 6); 
	MCUCR = MCUCR & 0b11110000;
	number=0;
	while (1) {
		seed++;
    }
}

// quick defines for die LEDS
#define p00 1
#define p01 2
#define p02 4
#define p10 8
#define p11 16
#define p12 32
#define p20 64
#define p21 128

ISR(INT0_vect) {
	_delay_ms(50);
	if (number ==0 ) {
		srand(seed);
	}
	number = rand()%6+1;
	// number to die decoder
	switch(number) {
		case 1:
			PORTA = p11;
			PORTB = 0;
			break;
		case 2:
			PORTA = p02 | p20;
			PORTB = 0;
			break;
		case 3:
			PORTA = p00 | p11;
			PORTB = 1;
			break;
		case 4:
			PORTA = p00 | p02 | p20;			
			PORTB = 1;
			break;
		case 5:
			PORTA = p00 | p02 | p20 | p11;
			PORTB = 1;
			break;
		case 6:
			PORTA = p00 | p02 | p10 | p12 | p20;
			PORTB = 1;
			break;
	}
	// put number to debug
	#ifdef UP_DEBUG
		PORTB |= number << 1;
	#endif
}