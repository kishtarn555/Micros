/*
 * globals.h
 *
 * Created: 23/02/2023 12:57:14 p. m.
 *  Author: Ferna
 */ 


#ifndef GLOBALS_H_
#define GLOBALS_H_

#define F_CPU 8000000



#endif /* GLOBALS_H_ */