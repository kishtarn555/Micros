/*
 * GccApplication1.c
 *
 * Created: 31/01/2023 03:29:40 p. m.
 * Author : Ferna
 */ 

#define F_CPU 1000000
#include <avr/io.h>
#include <stdint.h>
#include <util/delay.h>

int main(void)
{
    /* Replace with your application code */
    DDRA = 0;
    PORTA = 0b11111111;
    DDRC = 0b11111111;
	uint8_t counter = 0;
	uint8_t current = 0;
	uint8_t previous = 0;
	while (1) {
		// Read Input
		current = PINA;
		if (current == previous)
			continue;
			
		_delay_ms(50);
			if (((current^previous) & (1 << 0)) && !(current & (1 << 0))) {
				counter++;
				if (counter > 99) {
					counter = 99;
				}
		}
		if (((current^previous) & (1 << 7)) && !(current & (1 << 7))) {
			
			if (counter >0 ) {
			counter--;
			}
		}
		//Draw Counter
		PORTC = (counter/10)|((counter%10)<<4);		
		previous = current;
	}
	return 0;
}

