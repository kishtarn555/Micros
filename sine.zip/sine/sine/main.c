/*
 * sine.c
 *
 * Created: 21/02/2023 11:10:27 a. m.
 * Author : Ferna
 */ 

#define K_DEBUG
#include <avr/io.h>
#include <avr/interrupt.h>
#include <stdint.h>
#include "my_defines.h"

uint8_t sine[] = {238,212,189,238,238,212,189,238,189,178,158,189,178,158,158,141};

volatile uint8_t idx;

int main(void)
{
	idx =0;
	OCR0 = 128;
	// Activate TIMSK interrupts
	TIMSK = (1<<TOIE0);
	// Lets do a clock at  8 preescaler => 488 hz (Close-ish to 440) With non-inverted OC0
	uint8_t bla = TIMER0_FAST_PWM | PSCLR0_0 | (1<<COM01);
	TCCR0=0b01101001;
	sei(); 
	DDRB |= (1<<3);
	DDRD |= 1;
	PORTD |= 1;
    while (1) {

    }
}

ISR(TIMER0_OVF_vect) {
	idx++;
	#ifdef K_DEBUG
		if (idx==0) {
			PORTD ^= 1;
		}
	#endif
	OCR0 = sine[idx];
}

