/*
 * Keyboard.c
 *
 * Created: 07/02/2023 03:22:19 p. m.
 * Author : Ferna
 */ 

#define F_CPU 8000000
#include <avr/io.h>
#include <util/delay.h>
#include <stdint.h>

#define MAT_KEY_PIN PINA
#define MAT_KEY_DDR DDRA
#define MAT_KEY_PORT PORTA

#include "lcd.h"

void initMatrixKeyboard() {
	MAT_KEY_DDR = 0b11110000;
	MAT_KEY_PORT = 255;
}

uint8_t readFirstMatrixKeyboard() {	
	uint8_t returnCode=0;
	for (uint8_t i =0; i < 4; i++) {		
		MAT_KEY_PORT = 255 ^ (1<<(i+4));
		asm("nop");		
		uint8_t res = MAT_KEY_PIN & 15;
		if (res != 15) {
			_delay_ms(50);
			
			if (!(res &1)) {
				return returnCode+1;
			}
			if (!(res &2)) {
				return returnCode+2;
			}
			if (!(res &4)) {
				return returnCode+3;
			}
			if (!(res &8)) {
				return returnCode+4;
			}
		}
		returnCode+=4;
	}
	return 0;
}


int main(void)
{
	initMatrixKeyboard();
	lcd_init(LCD_DISP_ON);
    /* Replace with your application code */
    uint8_t response=0;
    uint8_t length=0;
    while (1) {
		while (!response) {
			response = readFirstMatrixKeyboard();
		}
		if (response == 4) {
			lcd_gotoxy(0,0);
			lcd_puts("          ");			
			lcd_gotoxy(0,0);
			length=0;
		} else if (length < 10) {
			lcd_putc(" D#0*C321B654A987"[response]);
			length++;
		}
		
		response=0;
    }
}

